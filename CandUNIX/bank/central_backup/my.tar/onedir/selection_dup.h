// selection.h
#ifndef _SELECTION_H
#define _SELECTION_H

int curr_channel ( void );
int max_channel ( void );
int dynamic_selection ( void );

# endif //_SELECTION_H
