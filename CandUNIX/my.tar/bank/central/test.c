# include "selection.h"
# include "selection.h"

# include <stdio.h>

main (  ) {
	printf ( "hai" );
}
