# include <stdio.h>

main  ( ) {
	printf ( "max->%d\n", max_channel ( ) );
	printf ( "min->%d\n", curr_channel ( ) );
}
