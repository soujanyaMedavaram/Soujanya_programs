date
pwd
echo hai
